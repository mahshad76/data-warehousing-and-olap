Python 3.7.4 (tags/v3.7.4:e09359112e, Jul  8 2019, 20:34:20) [MSC v.1916 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> from itertools import combinations
>>> import pandas as pd
>>> file = r'C:\Users\Mohammadreza Rahmani\Desktop\sports.csv'
>>> sport= pd.read_csv(file)
>>> gr=['A','B','C','D']
>>> gender=['M','F']
>>> continent=['Europe','Asia','South America','Africa','Oceania','North America','Other']
>>> 
>>> list=['sport','gr','continent','gender']
>>> index=(0,1,2,3)
>>> import mysql.connector
>>> import math
>>> qu=[]
>>> i=1
>>> while i<4:
	co=combinations(index,i)
	for k in co:
		reminder=[]
		x=0
		while x<len(index):
			t=0
			y=0
			while y<len(k):
				if index[x]==k[y]:
					t=1
					break
				else:
					y=y+1
			if t!=1:
				reminder.append(index[x])
			x=x+1
		d=1
		while d<=len(reminder):
			com=combinations(reminder,d)
			for k2 in com:
				if len(k2)==3:
					x1=list[k2[0]]
					y1=list[k2[1]]
					z1=list[k2[2]]
					if x1=='sport':
						mi=len(sport)
					if x1=='gr':
						mi=len(gr)
					if x1=='gender':
						mi=len(gender)
					if x1=='continent':
						mi=len(continent)
					if y1=='sport':
						mii=len(sport)
					if y1=='gr':
						mii=len(gr)
					if y1=='gender':
						mii=len(gender)
					if y1=='continent':
						mii=len(continent)
					if z1=='sport':
						miii=len(sport)
					if z1=='gr':
						miii=len(gr)
					if z1=='gender':
						miii=len(gender)
					if z1=='continent':
						miii=len(continent)
					a=0
					while a<mi:
						if x1=='gr':
							val1=gr[a]
						if x1=='sport':
							val1=sport.at[a,'sports']
						if x1=='gender':
							val1=gender[a]
						if x1=='continent':
							val1=continent[a]
						b=0
						while b<mii:
							if y1=='sport':
								val2=sport.at[b,'sports']
							if y1=='gender':
								val2=gender[b]
							if y1=='continent':
								val2=continent[b]
							if y1=='gr':
								val2=gr[b]
							c=0
							while c<miii:
								if z1=='sport':
									val3=sport.at[c,'sports']
								if z1=='continent':
									val3=continent[c]
								if z1=='gender':
									val3=gender[c]
								if z1=='gr':
									val3=gr[c]
								if len(k)==1:
									query="select"+" "+list[k[0]]+","+"sum"+"("+"gold"+")"+","+"sum"+"("+"silver"+")"+","+"sum"+"("+"bronze"+")"+" "+"from"+" "+"london12"+" "+"where"+" "+x1+"="+"'"+val1+"'"+" "+"and"+" "+y1+"="+"'"+val2+"'"+" "+"and"+" "+z1+"="+"'"+val3+"'"+" "+"group by"+" "+list[k[0]]
								qu.append(query)
								c=c+1
							b=b+1
						a=a+1
				if len(k2)==1:
					mi=0
					x1=list[k2[0]]
					ii1=0
					if x1=='sport':
						mi=len(sport)
					if x1=='gr':
						mi=len(gr)
					if x1=='gender':
						mi=len(gender)
					if x1=='continent':
						mi=len(continent)
					
					while ii1<mi:
						if x1=='sport':
							value=sport.at[ii1,'sports']
						else:
							if x1=='gr':
								value=gr[ii1]
							if x1=='gender':
								value=gender[ii1]
							if x1=='continent':
								value=continent[ii1]
						if len(k)==1:
							query="select"+" "+list[k[0]]+","+"sum"+"("+"gold"+")"+","+"sum"+"("+"silver"+")"+","+"sum"+"("+"bronze"+")"+" "+"from"+" "+"london12"+" "+"where"+" "+x1+"="+"'"+value+"'"+" "+"group by"+" "+list[k[0]]
						if len(k)==2:
							query="select"+" "+list[k[0]]+","+list[k[1]]+","+"sum"+"("+"gold"+")"+","+"sum"+"("+"silver"+")"+","+"sum"+"("+"bronze"+")"+" "+"from"+" "+"london12"+" "+"where"+" "+x1+"="+"'"+value+"'"+" "+"group by"+" "+list[k[0]]+","+list[k[1]]
						if len(k)==3:
							query="select"+" "+list[k[0]]+","+list[k[1]]+","+list[k[2]]+","+"sum"+"("+"gold"+")"+","+"sum"+"("+"silver"+")"+","+"sum"+"("+"bronze"+")"+" "+"from"+" "+"london12"+" "+"where"+" "+x1+"="+"'"+value+"'"+" "+"group by"+" "+list[k[0]]+","+list[k[1]]+","+list[k[2]]
						qu.append(query)
						ii1=ii1+1
				if len(k2)==2:
					x1=list[k2[0]]
					y1=list[k2[1]]
					if x1=='sport':
					        mi=len(sport)
					if x1=='gr':
						mi=len(gr)
					if x1=='gender':
						mi=len(gender)
					if x1=='continent':
						mi=len(continent)
					if y1=='sport':
						mii=len(sport)
					if y1=='gr':
						mii=len(gr)
					if y1=='gender':
						mii=len(gender)
					if y1=='continent':
						mii=len(continent)
					a=0
					val1=""
					while a<mi:
						b=0
						if x1=='sport':
							val1=sport.at[a,'sports']
						if x1=='continent':
							val1=continent[a]
						if x1=="gender":
							val1=gender[a]
						if x1=="gr":
							val1=gr[a]
						while b<mii:
							if y1=='continent':
								val2=continent[b]
							if y1=="gender":
								val2=gender[b]
							if y1=="gr":
								val2=gr[b]
							if y1=="sport":
								val2=sport.at[b,'sports']
							if len(k)==1:
								query="select"+" "+list[k[0]]+","+"sum"+"("+"gold"+")"+","+"sum"+"("+"silver"+")"+","+"sum"+"("+"bronze"+")"+" "+"from"+" "+"london12"+" "+"where"+" "+x1+"="+"'"+val1+"'"+" "+"and"+" "+y1+"="+"'"+val2+"'"+" "+"group by"+" "+list[k[0]]
							if len(k)==2:
							        query="select"+" "+list[k[0]]+","+list[k[1]]+","+"sum"+"("+"gold"+")"+","+"sum"+"("+"silver"+")"+","+"sum"+"("+"bronze"+")"+" "+"from"+" "+"london12"+" "+"where"+" "+x1+"="+"'"+val1+"'"+" "+"and"+" "+y1+"="+"'"+val2+"'"+" "+"group by"+" "+list[k[0]]+","+list[k[1]]
							qu.append(query)
							b=b+1
						a=a+1
			d=d+1
	i=i+1

	
>>> length=len(qu)
>>> length
3177
>>> i=0
>>> index_query=[]
>>> count_medal=[]
>>> while i<length:
	mydb=mysql.connector.connect(host="127.0.0.1",user="root",database="olapdb")
	mycursor=mydb.cursor()
	mycursor.execute(qu[i])
	result=mycursor.fetchall()
	if result!=[]:
		count_row=len(result)
		dimension=len(result[0])
		if count_row>=100:
			j=0
			counting=[]
			while j<count_row:
				su=0
				su=su+result[j][dimension-1]+result[j][dimension-2]+result[j][dimension-3]
				counting.append(su)
				j=j+1
			l=0
			si=0
			while l<len(counting):
				si=si+counting[l]
				l=l+1
			if si>=20:
				mu=si/len(counting)
				mf=0
				ss=0
				while mf<len(counting):
					ss=ss+math.pow((mu-counting[mf]),2)
					mf=mf+1
				variance=ss/len(counting)
				enheraf=math.pow(variance,1/2)
				mu=float(mu)
				count_medal.append(enheraf/mu)
				index_query.append(i)
	i=i+1

	
>>> mx=0
>>> maximum=count_medal[0]
>>> indent=0
>>> while mx<len(count_medal):
	if count_medal[mx]>maximum:
		maximum=count_medal[mx]
		indent=mx
	mx=mx+1

	
>>> c=index_query[indent]
>>> qu[c]
"select sport,gr,gender,sum(gold),sum(silver),sum(bronze) from london12 where continent='Africa' group by sport,gr,gender"
>>> u=0
>>> index_query=[]
>>> count_medal=[]
>>> length
3177
>>> while u<length:
	mydb=mysql.connector.connect(host="127.0.0.1",user="root",database="olapdb")
	mycursor=mydb.cursor()
	mycursor.execute(qu[u])
	result_set=mycursor.fetchall()
	count_row=len(result_set)
	if count_row>=10:
		su=0
		dimension=len(result_set[0])
		j=0
		while j<count_row:
			su=su+result_set[j][dimension-3]+result_set[j][dimension-2]+result_set[j][dimension-1]
			j=j+1
		d=su/count_row
		index_query.append(u)
		count_medal.append(d)
	u=u+1

	
>>> mx=0
>>> maximum=count_medal[0]
>>> indent=0
>>> while mx<len(count_medal):
	if count_medal[mx]>maximum:
		maximum=count_medal[mx]
		indent=mx
	mx=mx+1

	
>>> a=index_query[indent]
>>> qu[a]
"select continent,gender,sum(gold),sum(silver),sum(bronze) from london12 where gr='C' group by continent,gender"
>>> i=0
>>> index_query=[]
>>> count_medal=[]
>>> while i<length:
	mydb=mysql.connector.connect(host="127.0.0.1",user="root",database="olapdb")
	mycursor=mydb.cursor()
	mycursor.execute(qu[i])
	result=mycursor.fetchall()
	if result!=[]:
	        dimension=len(result[0])
	        j=0
	        count_row=len(result)
	        su_all=0
	        su_sb=0
	        while j<count_row:
		                su_all=su_all+result[j][dimension-2]+result[j][dimension-1]+result[j][dimension-3]
		                su_sb=su_sb+result[j][dimension-2]+result[j][dimension-1]
		                j=j+1
	        if su_sb>=(9*su_all)/10:
		        index_query.append(i)
		        count_medal.append(su_all)
	i=i+1

	
>>> mx=0
>>> maximum=count_medal[0]
>>> indent=0
>>> while mx<len(count_medal):
	if count_medal[mx]>maximum:
		maximum=count_medal[mx]
		indent=mx
	mx=mx+1

	
>>> b=index_query[indent]
>>> qu[b]
"select sport,sum(gold),sum(silver),sum(bronze) from london12 where continent='South America' and gender='M' group by sport"
>>> i=0
>>> index_query=[]
>>> count_medal=[]
>>> while i<length:
	mydb=mysql.connector.connect(host="127.0.0.1",user="root",database="olapdb")
	mycursor=mydb.cursor()
	mycursor.execute(qu[i])
	result=mycursor.fetchall()
	if result!=[]:
	        dimension=len(result[0])
	        j=0
	        count_row=len(result)
	        su_all=0
	        su_sb=0
	        while j<count_row:
		                su_all=su_all+result[j][dimension-2]+result[j][dimension-1]+result[j][dimension-3]
		                su_sb=su_sb+result[j][dimension-3]
		                j=j+1
	        if su_sb>=(5*su_all)/10:
		        index_query.append(i)
		        count_medal.append(su_all)
	i=i+1

	
>>> mx=0
>>> maximum=count_medal[0]
>>> indent=0
>>> while mx<len(count_medal):
	if count_medal[mx]>maximum:
		maximum=count_medal[mx]
		indent=mx
	mx=mx+1

	
>>> c=index_query[indent]
>>> qu[c]
"select sport,sum(gold),sum(silver),sum(bronze) from london12 where gr='B' and continent='North America' group by sport"
>>> 
