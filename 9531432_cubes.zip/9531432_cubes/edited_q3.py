Python 3.7.4 (tags/v3.7.4:e09359112e, Jul  8 2019, 20:34:20) [MSC v.1916 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> import random
>>> import mysql.connector
>>> from itertools import combinations
>>> list=['sport','gr','country','continent','gender']
>>> mydb=mysql.connector.connect(host="127.0.0.1",user="root",database="olapdb")
>>> mycursor=mydb.cursor()
>>> j=0
>>> res=""
>>> co=combinations(list,1)
>>> for i in co:
	charset='1234567890abcdefghijklmnpqrstuvwxyz'
	randomstr=""
	for k in range(0,6):
		randomstr+=random.choice(charset)
	query="CREATE INDEX"+" "+randomstr+" "+"ON london12"+"("+str(i[0])+")"
	mycursor.execute(query)

	
>>> for len in range(2,6):
	co=combinations(list,len)
	m=0
	
	for i in co:
		st=""
		k=0
		while(k<len):
			if k<len-1:
			 st+=i[k]+','
			else:
				st+=i[k]
			k=k+1
		charset='abcdefghijklmnpqrstuvzmnbhqwerttrezxcvbnm'
		randomstr=""
		for k in range(0,6):
			randomstr+=random.choice(charset)
		query="CREATE INDEX"+" "+randomstr+" "+"ON london12"+"("+st+")"
		mycursor.execute(query)

		
>>> 
